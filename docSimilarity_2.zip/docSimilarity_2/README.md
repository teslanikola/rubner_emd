# docSimilarity
gcc -o libWMDJNIWrapperImpl.so -lc -shared -I/home/abhishek/jdk1.8.0_25/include -I/home/abhishek/jdk1.8.0_25/include/linux -fPIC WMDWrapper.c emd.c
